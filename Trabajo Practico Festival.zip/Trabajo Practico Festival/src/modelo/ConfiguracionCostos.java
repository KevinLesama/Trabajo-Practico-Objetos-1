package modelo;

public class ConfiguracionCostos {

}
