package modelo;

public class UnidadVenta {

}
